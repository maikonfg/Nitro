# Nitro

App Android feito do zero (Java puro; a única biblioteca é o SDK de anúncios do Google AdMob) pra
liberar RAM e tirar peso de segundo plano antes de jogar. Sem root, sem ADB, sem Brevent/Shizuku. Não mexe na resolução.

## O que ele faz
- **Painel ao vivo:** RAM em uso (mostrador de conta-giros), swap/zRAM, temperatura e CPU.
- **Turbo:** 1) limpeza leve em todos os apps abertos; 2) "Forçar parada" de verdade, app por app,
  por um serviço de acessibilidade que só enxerga a tela de Configurações.
- **Modo Jogo:** escolhe jogos/emuladores, o botão Jogar roda o Turbo e abre o jogo. Avisa se o
  aparelho está quente ou em economia de energia (os dois seguram CPU/GPU).
- **Protegidos:** WhatsApp/Telegram já vêm protegidos. Launcher, teclado, discador e SMS são
  protegidos automaticamente. Apps de sistema só entram se você ligar a opção avançada.
- **Atalhos:** bloquinho "Turbo" nas configurações rápidas e atalho no ícone do app.
- **Ajustes manuais** com atalho direto: limite de processos (Opções do desenvolvedor), economia
  de energia, taxa de atualização, apps por cima de outros apps, bateria.

## O que ele NÃO faz
Sem root/ADB, nenhum app consegue subir o clock da CPU/GPU nem trocar governor. O ganho aqui é
indireto: mais RAM livre, menos zRAM/swap comprimindo (gasta CPU) e menos processo disputando
CPU/GPU com o jogo.

## Anúncios (AdMob)
Um banner fino fica fixo embaixo da tela principal e só aparece quando carrega (sem internet, nada muda).
Tudo se configura no começo do `app/build.gradle`:
- `adsTeste = true`: usa os IDs de **teste** do Google. É o certo enquanto você desenvolve (anúncio vem
  escrito "Test Ad" e pode clicar à vontade).
- `adsTeste = false`: usa os seus IDs reais (`adsAppIdReal` e `adsBannerIdReal`). Só na versão final.
  **Nunca clique nos anúncios reais do seu próprio app**: o AdMob pode suspender a conta.
- Bloco de anúncio novo no AdMob pode levar um tempo pra começar a entregar anúncio. Nesse intervalo o
  banner simplesmente não aparece (erro "no fill" no Logcat, tag `NitroAds`).
- O SDK exige `compileSdk 35`, `minSdk 24+` e AndroidX ligado (`gradle.properties`). Já está tudo ajustado.

## Gerar o APK
Escolha um:
1. **GitHub Actions (sem instalar nada):** suba esta pasta inteira num repositório (no navegador do
   PC dá pra arrastar a pasta). O workflow `.github/workflows/build.yml` compila e deixa o
   `app-debug.apk` em Actions > Gerar APK > Artifacts.
2. **Android Studio:** File > Open nesta pasta > Build > Build APK(s).
3. **AndroidIDE (no celular):** abra a pasta e rode `assembleDebug`. Se reclamar do wrapper, crie
   um projeto vazio e copie a pasta `gradle/` e o `gradlew` dele pra cá.

## Ativar o serviço (uma vez)
Configurações > Acessibilidade > Apps instalados > Nitro (Turbo). Se estiver cinza ("configuração
restrita"): Info do app do Nitro > três pontinhos > Permitir configurações restritas.
Depois deixe o Nitro "sem restrição" de bateria, senão o Android pode desligar o serviço.

## Outras marcas
O serviço só escuta `com.android.settings` (Samsung/Pixel). Em outra marca, ajuste `packageNames`
em `res/xml/accessibility_service_config.xml` e os textos em `NitroAccessibilityService.java`.
