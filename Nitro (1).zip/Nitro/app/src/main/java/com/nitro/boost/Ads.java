package com.nitro.boost;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.google.android.libraries.ads.mobile.sdk.MobileAds;
import com.google.android.libraries.ads.mobile.sdk.banner.AdSize;
import com.google.android.libraries.ads.mobile.sdk.banner.AdView;
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAd;
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAdRequest;
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback;
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError;
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig;

/**
 * Banner do Google AdMob na parte de baixo da tela principal.
 *
 * Os IDs (App ID e ID do banner) ficam em app/build.gradle, não aqui.
 * Anúncio nunca pode derrubar o app: qualquer erro só vira uma linha no Logcat e o banner some.
 */
final class Ads {
    private static final String TAG = "NitroAds";
    private static boolean sdkReady;

    private Ads() { }

    /** Inicia o SDK (uma vez só, fora da thread da tela) e põe o banner dentro de {@code box}. */
    static void attachBanner(final Activity activity, final FrameLayout box) {
        final Context app = activity.getApplicationContext();
        new Thread(() -> {
            try {
                ensureInit(app);
                activity.runOnUiThread(() -> loadBanner(activity, box));
            } catch (Throwable e) {
                Log.w(TAG, "Anúncios desligados: " + e);
            }
        }, "nitro-ads").start();
    }

    /** Tira o banner da tela e libera a memória dele. Chame no onDestroy. */
    static void detach(FrameLayout box) {
        for (int i = box.getChildCount() - 1; i >= 0; i--) {
            View v = box.getChildAt(i);
            box.removeViewAt(i);
            if (v instanceof AdView) {
                ((AdView) v).destroy();
            }
        }
        box.setVisibility(View.GONE);
    }

    /** O SDK pede que a inicialização rode em thread de fundo, senão pode dar ANR. */
    private static synchronized void ensureInit(Context app) {
        if (sdkReady) return;
        MobileAds.initialize(
                app,
                new InitializationConfig.Builder(app.getString(R.string.ads_app_id)).build(),
                initializationStatus -> {
                    Log.d(TAG, "SDK de anúncios pronto.");
                });
        sdkReady = true;
    }

    private static void loadBanner(final Activity activity, final FrameLayout box) {
        if (activity.isFinishing() || activity.isDestroyed()) return;
        try {
            final AdView adView = new AdView(activity);
            box.removeAllViews();
            box.addView(adView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER_HORIZONTAL));

            // 320x50: fino, não come tela do app. Pra um banner maior e mais rentável,
            // troque por AdSize.getLargeAnchoredAdaptiveBannerAdSize(activity, larguraEmDp).
            BannerAdRequest request = new BannerAdRequest.Builder(
                    activity.getString(R.string.ads_banner_id), AdSize.BANNER).build();

            adView.loadAd(request, new AdLoadCallback<BannerAd>() {
                @Override
                public void onAdLoaded(BannerAd ad) {
                    activity.runOnUiThread(() -> box.setVisibility(View.VISIBLE));
                }

                @Override
                public void onAdFailedToLoad(LoadAdError error) {
                    Log.w(TAG, "Banner não carregou: " + error);
                }
            });
        } catch (Throwable e) {
            Log.w(TAG, "Banner desligado: " + e);
        }
    }
}
