package com.nitro.boost;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.provider.Settings;
import android.provider.Telephony;
import android.telecom.TelecomManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Quais apps o Turbo pode fechar e quais ele nunca encosta. */
final class Apps {
    private Apps() { }

    static final class Entry {
        String pkg;
        String label;
        boolean user;
        boolean stopped;
        boolean game;
    }

    /** Pacotes de sistema que o Nitro nunca mexe, nem com "incluir apps do sistema" ligado. */
    private static final String[] NEVER = {
            "com.android.systemui", "com.android.phone", "com.android.settings", "com.android.providers.",
            "com.android.server.", "com.android.bluetooth", "com.android.nfc", "com.android.inputmethod",
            "com.android.launcher", "com.android.packageinstaller", "com.google.android.gms",
            "com.google.android.gsf", "com.google.android.permissioncontroller",
            "com.google.android.packageinstaller", "com.google.android.inputmethod",
            "com.google.android.webview", "com.samsung.android.incallui", "com.samsung.android.dialer",
            "com.samsung.android.app.telephonyui", "com.samsung.android.messaging",
            "com.sec.android.app.launcher", "com.sec.android.inputmethod", "com.samsung.android.honeyboard",
            "com.samsung.android.knox", "com.samsung.android.service", "com.samsung.android.providers",
            "com.samsung.android.bluetooth", "com.sec.imsservice", "com.sec.android.provider",
            "com.samsung.android.networkstack"
    };

    static boolean neverTouch(String pkg) {
        if (pkg.equals("android")) return true;
        for (String p : NEVER) {
            if (pkg.startsWith(p)) return true;
        }
        return false;
    }

    @SuppressWarnings("deprecation")
    private static List<ApplicationInfo> installed(Context c) {
        PackageManager pm = c.getPackageManager();
        if (Build.VERSION.SDK_INT >= 33) {
            return pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0));
        }
        return pm.getInstalledApplications(0);
    }

    /** App "de usuário": instalado por você ou atualização de app de sistema (Chrome, YouTube...). */
    private static boolean isUser(ApplicationInfo ai) {
        return (ai.flags & ApplicationInfo.FLAG_SYSTEM) == 0
                || (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
    }

    @SuppressWarnings("deprecation")
    static boolean isStopped(Context c, String pkg) {
        try {
            return (c.getPackageManager().getApplicationInfo(pkg, 0).flags & ApplicationInfo.FLAG_STOPPED) != 0;
        } catch (Exception e) {
            return false;
        }
    }

    @SuppressWarnings("deprecation")
    static String label(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return pkg;
        }
    }

    /** Launcher, teclado, discador, SMS, serviços de acessibilidade ativos e o próprio Nitro. */
    static Set<String> dynamicProtected(Context c) {
        Set<String> s = new HashSet<>();
        s.add(c.getPackageName());
        try {
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            ResolveInfo ri = c.getPackageManager().resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
            if (ri != null && ri.activityInfo != null) s.add(ri.activityInfo.packageName);
        } catch (Exception ignored) {
            // segue sem essa proteção
        }
        try {
            addComponentPackage(s, Settings.Secure.getString(
                    c.getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD));
        } catch (Exception ignored) {
            // segue
        }
        try {
            String acc = Settings.Secure.getString(
                    c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (acc != null) {
                for (String part : acc.split(":")) addComponentPackage(s, part);
            }
        } catch (Exception ignored) {
            // segue
        }
        try {
            TelecomManager tm = (TelecomManager) c.getSystemService(Context.TELECOM_SERVICE);
            String dialer = tm == null ? null : tm.getDefaultDialerPackage();
            if (dialer != null) s.add(dialer);
        } catch (Exception ignored) {
            // segue
        }
        try {
            String sms = Telephony.Sms.getDefaultSmsPackage(c);
            if (sms != null) s.add(sms);
        } catch (Exception ignored) {
            // segue
        }
        return s;
    }

    private static void addComponentPackage(Set<String> s, String flat) {
        if (flat == null) return;
        int i = flat.indexOf('/');
        if (i > 0) s.add(flat.substring(0, i));
    }

    /** Pacotes que o Turbo vai fechar agora: abertos (não parados), com ícone e não protegidos. */
    static List<String> targets(Context c, String exclude) {
        PackageManager pm = c.getPackageManager();
        Prefs prefs = new Prefs(c);
        Set<String> protect = prefs.get(Prefs.K_PROTECT);
        protect.addAll(dynamicProtected(c));
        boolean sys = prefs.includeSystem();
        List<String> out = new ArrayList<>();
        for (ApplicationInfo ai : installed(c)) {
            String p = ai.packageName;
            if (p.equals(exclude) || protect.contains(p)) continue;
            if (!ai.enabled) continue;
            if ((ai.flags & ApplicationInfo.FLAG_STOPPED) != 0) continue;
            boolean user = isUser(ai);
            if (!user && (!sys || neverTouch(p))) continue;
            if (pm.getLaunchIntentForPackage(p) == null) continue;
            out.add(p);
        }
        return out;
    }

    /** Lista pra tela de escolha (com rótulo, então é lenta: chame fora da thread principal). */
    static List<Entry> list(Context c, boolean includeSystem) {
        PackageManager pm = c.getPackageManager();
        List<Entry> out = new ArrayList<>();
        for (ApplicationInfo ai : installed(c)) {
            String p = ai.packageName;
            if (p.equals(c.getPackageName())) continue;
            boolean user = isUser(ai);
            if (!user && (!includeSystem || neverTouch(p))) continue;
            if (pm.getLaunchIntentForPackage(p) == null) continue;
            Entry e = new Entry();
            e.pkg = p;
            e.label = String.valueOf(pm.getApplicationLabel(ai));
            e.user = user;
            e.stopped = (ai.flags & ApplicationInfo.FLAG_STOPPED) != 0;
            e.game = ai.category == ApplicationInfo.CATEGORY_GAME;
            out.add(e);
        }
        Collections.sort(out, (a, b) -> a.label.compareToIgnoreCase(b.label));
        return out;
    }
}
