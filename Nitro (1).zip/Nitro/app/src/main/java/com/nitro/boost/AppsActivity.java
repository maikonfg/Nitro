package com.nitro.boost;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Lista de apps com caixinha: serve pra escolher os protegidos e pra escolher os jogos. */
public class AppsActivity extends Activity {
    static final String EXTRA_MODE = "mode";
    static final String MODE_PROTECT = "protect";
    static final String MODE_GAMES = "games";
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;

    private boolean games;
    private String key;
    private Prefs prefs;
    private Set<String> chosen;
    private final List<Apps.Entry> all = new ArrayList<>();
    private final List<Apps.Entry> shown = new ArrayList<>();
    private final LruCache<String, Drawable> icons = new LruCache<>(160);
    private AppAdapter adapter;
    private TextView count;
    private TextView loading;
    private String query = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        games = MODE_GAMES.equals(getIntent().getStringExtra(EXTRA_MODE));
        key = games ? Prefs.K_GAMES : Prefs.K_PROTECT;
        prefs = new Prefs(this);
        chosen = prefs.get(key);
        setContentView(buildUi());
        load();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(0, Ui.dp(this, 20), 0, 0);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setPadding(Ui.dp(this, 20), 0, Ui.dp(this, 20), 0);
        head.addView(Ui.title(this, games ? "Jogos do Modo Jogo" : "Apps protegidos", 28));
        TextView sub = Ui.text(this, games
                ? "Marque os jogos e emuladores que você quer abrir junto com o Turbo."
                : "O Turbo não fecha os marcados. Os que podem estar abertos aparecem primeiro.", 13, Ui.MUTED);
        sub.setLineSpacing(0f, 1.15f);
        head.addView(sub, Ui.lp(this, MATCH, WRAP, 0, 6, 0, 0));

        EditText search = new EditText(this);
        search.setHint("Buscar app");
        search.setHintTextColor(Ui.MUTED);
        search.setTextColor(Ui.TEXT);
        search.setTextSize(15);
        search.setSingleLine(true);
        search.setBackground(Ui.rect(this, Ui.RAISED, 16));
        search.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12));
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                query = s.toString().trim().toLowerCase(Locale.getDefault());
                applyFilter();
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });
        head.addView(search, Ui.lp(this, MATCH, WRAP, 0, 16, 0, 0));

        count = Ui.text(this, "", 13, Ui.MUTED);
        head.addView(count, Ui.lp(this, MATCH, WRAP, 0, 12, 0, 8));
        loading = Ui.text(this, "Carregando apps…", 14, Ui.MUTED);
        head.addView(loading, Ui.lp(this, MATCH, WRAP, 0, 4, 0, 8));
        root.addView(head);

        adapter = new AppAdapter();
        ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setDividerHeight(0);
        lv.setSelector(new ColorDrawable(Color.TRANSPARENT));
        lv.setAdapter(adapter);
        lv.setOnItemClickListener((p, v, pos, id) -> toggle(pos));
        root.addView(lv, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        return root;
    }

    private void load() {
        final boolean sys = !games && prefs.includeSystem();
        new Thread(() -> {
            final List<Apps.Entry> list = Apps.list(this, sys);
            if (!games) {
                // Launcher, teclado etc. já são protegidos sozinhos; não precisa aparecer.
                final Set<String> auto = Apps.dynamicProtected(this);
                list.removeIf(e -> auto.contains(e.pkg));
            }
            runOnUiThread(() -> {
                all.clear();
                all.addAll(list);
                sortAll();
                loading.setVisibility(View.GONE);
                applyFilter();
            });
        }).start();
    }

    private void sortAll() {
        Collections.sort(all, (a, b) -> {
            boolean ca = chosen.contains(a.pkg);
            boolean cb = chosen.contains(b.pkg);
            if (ca != cb) return ca ? -1 : 1;
            boolean ha = games ? a.game : !a.stopped;
            boolean hb = games ? b.game : !b.stopped;
            if (ha != hb) return ha ? -1 : 1;
            return a.label.compareToIgnoreCase(b.label);
        });
    }

    private void applyFilter() {
        shown.clear();
        for (Apps.Entry e : all) {
            if (query.isEmpty()
                    || e.label.toLowerCase(Locale.getDefault()).contains(query)
                    || e.pkg.contains(query)) {
                shown.add(e);
            }
        }
        adapter.notifyDataSetChanged();
        count.setText(games
                ? chosen.size() + " no Modo Jogo"
                : chosen.size() + " protegidos (o Turbo não fecha)");
    }

    private void toggle(int pos) {
        if (pos < 0 || pos >= shown.size()) return;
        String pkg = shown.get(pos).pkg;
        if (!chosen.remove(pkg)) chosen.add(pkg);
        prefs.put(key, chosen);
        adapter.notifyDataSetChanged();
        count.setText(games
                ? chosen.size() + " no Modo Jogo"
                : chosen.size() + " protegidos (o Turbo não fecha)");
    }

    private Drawable icon(String pkg) {
        Drawable d = icons.get(pkg);
        if (d == null) {
            try {
                d = getPackageManager().getApplicationIcon(pkg);
                icons.put(pkg, d);
            } catch (Exception e) {
                return null;
            }
        }
        return d;
    }

    private String subtitle(Apps.Entry e) {
        if (games) return e.game ? "Jogo" : e.pkg;
        if (!e.user) return e.stopped ? "App do sistema, parado" : "App do sistema";
        return e.stopped ? "Parado" : "Pode estar aberto";
    }

    private final class Row {
        final LinearLayout root;
        final ImageView icon;
        final TextView name;
        final TextView sub;
        final CheckBox box;

        Row(Context c) {
            root = new LinearLayout(c);
            root.setOrientation(LinearLayout.HORIZONTAL);
            root.setGravity(Gravity.CENTER_VERTICAL);
            root.setPadding(Ui.dp(c, 20), Ui.dp(c, 10), Ui.dp(c, 16), Ui.dp(c, 10));
            root.setBackground(Ui.rowRipple());

            icon = new ImageView(c);
            root.addView(icon, new LinearLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 44)));

            LinearLayout texts = new LinearLayout(c);
            texts.setOrientation(LinearLayout.VERTICAL);
            name = Ui.text(c, "", 16, Ui.TEXT);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            sub = Ui.text(c, "", 12, Ui.MUTED);
            sub.setSingleLine(true);
            sub.setEllipsize(TextUtils.TruncateAt.END);
            texts.addView(name);
            texts.addView(sub, Ui.lp(c, WRAP, WRAP, 0, 2, 0, 0));
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, WRAP, 1f);
            tp.setMargins(Ui.dp(c, 14), 0, Ui.dp(c, 8), 0);
            root.addView(texts, tp);

            box = new CheckBox(c);
            box.setClickable(false);
            box.setFocusable(false);
            box.setButtonTintList(ColorStateList.valueOf(Ui.ACCENT));
            root.addView(box);
        }
    }

    private final class AppAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return shown.size();
        }

        @Override
        public Object getItem(int i) {
            return shown.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int pos, View cv, ViewGroup parent) {
            Row r;
            if (cv == null) {
                r = new Row(AppsActivity.this);
                cv = r.root;
                cv.setTag(r);
            } else {
                r = (Row) cv.getTag();
            }
            Apps.Entry e = shown.get(pos);
            r.name.setText(e.label);
            r.sub.setText(subtitle(e));
            r.icon.setImageDrawable(icon(e.pkg));
            r.box.setChecked(chosen.contains(e.pkg));
            return cv;
        }
    }
}
