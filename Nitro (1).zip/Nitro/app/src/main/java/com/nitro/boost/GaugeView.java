package com.nitro.boost;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.OvershootInterpolator;

/** Mostrador de RAM em uso, estilo conta-giros: marcações, zona vermelha e ponteiro. */
final class GaugeView extends View {
    private static final float START = 135f;
    private static final float SWEEP = 270f;
    private static final int TICKS = 20;

    private final float d;
    private final Paint face = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint band = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint needle = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hub = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint big = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();

    private float shown;
    private float target = -1f;
    private String bigText = "--";
    private String smallText = "";
    private ValueAnimator anim;

    GaugeView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        face.setColor(Ui.DEEP);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(1.5f * d);
        ring.setColor(Ui.LINE);
        tick.setStrokeCap(Paint.Cap.ROUND);
        band.setStyle(Paint.Style.STROKE);
        band.setStrokeWidth(6f * d);
        band.setStrokeCap(Paint.Cap.ROUND);
        needle.setStrokeWidth(3f * d);
        needle.setStrokeCap(Paint.Cap.ROUND);
        needle.setColor(Ui.TEXT);
        hub.setColor(Ui.ACCENT);
        big.setColor(Ui.TEXT);
        big.setTextAlign(Paint.Align.CENTER);
        big.setTextSize(54f * d);
        big.setTypeface(Ui.condensed());
        small.setColor(Ui.MUTED);
        small.setTextAlign(Paint.Align.CENTER);
        small.setTextSize(14f * d);
    }

    /** frac = 0..1 de uso; os textos aparecem embaixo do ponteiro. */
    void set(float frac, String bigText, String smallText) {
        this.bigText = bigText;
        this.smallText = smallText;
        float t = Math.max(0f, Math.min(1f, frac));
        if (Math.abs(t - target) < 0.004f) {
            invalidate();
            return;
        }
        target = t;
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(shown, t);
        anim.setDuration(Math.abs(t - shown) > 0.08f ? 900 : 350);
        anim.setInterpolator(new OvershootInterpolator(0.9f));
        anim.addUpdateListener(a -> {
            shown = (Float) a.getAnimatedValue();
            invalidate();
        });
        anim.start();
    }

    private static int levelColor(float v) {
        if (v < 0.70f) return Ui.OK;
        if (v < 0.85f) return Ui.WARN;
        return Ui.BAD;
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;
        float r = Math.min(w, h) / 2f - 4f * d;

        c.drawCircle(cx, cy, r, face);
        c.drawCircle(cx, cy, r, ring);

        float outer = r - 12f * d;
        for (int i = 0; i <= TICKS; i++) {
            float f = i / (float) TICKS;
            boolean major = i % 5 == 0;
            float len = (major ? 15f : 8f) * d;
            double a = Math.toRadians(START + SWEEP * f);
            float cos = (float) Math.cos(a);
            float sin = (float) Math.sin(a);
            tick.setStrokeWidth((major ? 3f : 1.6f) * d);
            tick.setColor(f >= 0.85f ? Ui.ACCENT : (major ? Ui.TEXT : Ui.MUTED));
            c.drawLine(cx + cos * outer, cy + sin * outer, cx + cos * (outer - len), cy + sin * (outer - len), tick);
        }

        float v = Math.max(0f, Math.min(1f, shown));
        float br = outer - 28f * d;
        box.set(cx - br, cy - br, cx + br, cy + br);
        band.setColor(Ui.RAISED);
        c.drawArc(box, START, SWEEP, false, band);
        if (v > 0.002f) {
            band.setColor(levelColor(v));
            c.drawArc(box, START, SWEEP * v, false, band);
        }

        float pos = Math.max(-0.03f, Math.min(1.03f, shown));
        double na = Math.toRadians(START + SWEEP * pos);
        float nl = br - 10f * d;
        c.drawLine(cx, cy, cx + (float) Math.cos(na) * nl, cy + (float) Math.sin(na) * nl, needle);
        c.drawCircle(cx, cy, 9f * d, hub);

        float baseline = cy + r * 0.62f;
        c.drawText(bigText, cx, baseline, big);
        c.drawText(smallText, cx, baseline + 22f * d, small);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }
}
