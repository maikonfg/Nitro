package com.nitro.boost;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements TurboEngine.Listener {
    static final String ACTION_TURBO = "com.nitro.boost.TURBO";
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private TurboEngine engine;
    private Prefs prefs;
    private boolean resumed;
    private boolean pendingTurbo;
    private String alertKey = "";

    private LinearLayout alerts;
    private LinearLayout gamesBox;
    private GaugeView gauge;
    private TextView ramCaption;
    private TextView swapV;
    private TextView tempV;
    private TextView cpuV;
    private TextView turboBtn;
    private TextView status;
    private TextView svcState;
    private ProgressBar progress;
    private FrameLayout adBox;

    private final Runnable statsTick = new Runnable() {
        @Override
        public void run() {
            refreshStats();
            ui.postDelayed(this, 1500);
        }
    };

    private final Runnable driveRunnable = new Runnable() {
        @Override
        public void run() {
            drive();
        }
    };

    // ---------------------------------------------------------------- ciclo de vida

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        engine = TurboEngine.get(this);
        prefs = new Prefs(this);
        setContentView(buildUi());
        Ads.attachBanner(this, adBox);
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent i) {
        if (i != null && ACTION_TURBO.equals(i.getAction())) {
            pendingTurbo = true;
            i.setAction(null);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        engine.setListener(this);
        refreshGames();
        refreshService();
        ui.removeCallbacks(statsTick);
        ui.post(statsTick);
        if (pendingTurbo) {
            pendingTurbo = false;
            if (!engine.busy()) {
                runTurbo(null);
                return;
            }
        }
        if (engine.state == TurboEngine.State.NEEDS_LAUNCH) {
            setBusy(true);
            ui.removeCallbacks(driveRunnable);
            ui.postDelayed(driveRunnable, 200);
        }
    }

    @Override
    protected void onPause() {
        resumed = false;
        ui.removeCallbacks(statsTick);
        ui.removeCallbacks(driveRunnable);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        Ads.detach(adBox);
        engine.setListener(null);
        super.onDestroy();
    }

    // ---------------------------------------------------------------- Turbo

    private void onTurboClick() {
        if (engine.busy()) {
            engine.cancel();
            setStatus("Cancelando assim que terminar o app atual…");
            return;
        }
        runTurbo(null);
    }

    private void runTurbo(String launch) {
        if (engine.busy()) {
            toast("O Turbo já está rodando.");
            return;
        }
        engine.setListener(this);
        if (!engine.start(launch)) return;
        setBusy(true);
        progress.setMax(Math.max(1, engine.queue.size()));
        progress.setProgress(0);
        boolean deep = engine.state == TurboEngine.State.NEEDS_LAUNCH;
        setStatus(deep ? "Turbo total: a tela vai piscar por alguns segundos." : "Limpeza leve…");
        if (deep) drive();
    }

    /** Abre a Info do próximo app; o serviço aperta Forçar parada e volta pra cá. */
    private void drive() {
        if (!resumed || engine.state != TurboEngine.State.NEEDS_LAUNCH) return;
        String pkg = engine.takeNext();
        if (pkg == null) {
            setStatus("Medindo o resultado…");
            engine.finishRun();
            return;
        }
        progress.setProgress(engine.idx - 1);
        setStatus("Fechando " + Apps.label(this, pkg) + " (" + engine.idx + " de " + engine.queue.size() + ")");
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", pkg, null)));
            overridePendingTransition(0, 0);
        } catch (Exception e) {
            engine.endStep(TurboEngine.Outcome.TIMEOUT);
        }
    }

    @Override
    public void onNext() {
        if (!resumed) return;
        ui.removeCallbacks(driveRunnable);
        ui.postDelayed(driveRunnable, 150);
    }

    @Override
    public void onDone(TurboEngine.Result r) {
        setBusy(false);
        setStatus(summary(r));
        refreshStats();
        if (r.launch != null && resumed) launchGame(r.launch);
    }

    private String summary(TurboEngine.Result r) {
        if (r.total == 0) {
            return "Não tinha nada aberto pra fechar. RAM livre: " + SysInfo.gb(r.availAfterKb) + ".";
        }
        long gain = (r.availAfterKb - r.availBeforeKb) / 1024;
        String head;
        if (r.deep) {
            head = r.stopped + (r.stopped == 1 ? " app parado" : " apps parados");
            int other = r.skipped + r.failed;
            if (other > 0) head += ", " + other + " não deu";
        } else {
            head = "Limpeza leve em " + r.total + " apps";
        }
        String ram = gain > 0
                ? "RAM livre foi de " + SysInfo.gb(r.availBeforeKb) + " para " + SysInfo.gb(r.availAfterKb)
                + " (+" + gain + " MB)."
                : "RAM livre ficou em " + SysInfo.gb(r.availAfterKb) + ": o Android já tinha liberado o que dava.";
        String tip = r.deep ? "" : " Ative o serviço pra fechar de verdade.";
        return head + ". " + ram + tip;
    }

    private void setBusy(boolean busy) {
        turboBtn.setText(busy ? "Cancelar" : "Turbo");
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
    }

    private void setStatus(String s) {
        status.setText(s);
    }

    // ---------------------------------------------------------------- Modo Jogo

    private void play(String pkg) {
        StringBuilder w = new StringBuilder();
        float t = SysInfo.batteryTempC(this);
        if (SysInfo.thermal(this) >= 2 || t >= 43f) {
            w.append("• O aparelho está quente");
            if (t > 0) w.append(" (").append(SysInfo.temp(t)).append(")");
            w.append(". O Android reduz CPU e GPU sozinho pra esfriar.\n");
        }
        boolean save = SysInfo.powerSave(this);
        if (save) w.append("• A economia de energia está ligada e segura CPU e GPU.\n");
        if (w.length() == 0) {
            runTurbo(pkg);
            return;
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Antes de jogar")
                .setMessage(w.toString().trim())
                .setPositiveButton("Jogar mesmo assim", (d, i) -> runTurbo(pkg))
                .setNegativeButton("Cancelar", null);
        if (save) {
            b.setNeutralButton("Economia de energia", (d, i) -> open(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        }
        b.show();
    }

    private void launchGame(String pkg) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) {
            toast("Não achei esse app.");
            return;
        }
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Não consegui abrir o jogo.");
        }
    }

    private void refreshGames() {
        gamesBox.removeAllViews();
        PackageManager pm = getPackageManager();
        List<String[]> items = new ArrayList<>();
        for (String pkg : prefs.get(Prefs.K_GAMES)) {
            try {
                ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                items.add(new String[] { String.valueOf(pm.getApplicationLabel(ai)), pkg });
            } catch (Exception ignored) {
                // desinstalado
            }
        }
        Collections.sort(items, (a, b) -> a[0].compareToIgnoreCase(b[0]));
        if (items.isEmpty()) {
            TextView t = Ui.text(this, "Nenhum jogo escolhido ainda.", 14, Ui.MUTED);
            t.setPadding(Ui.dp(this, 16), Ui.dp(this, 18), Ui.dp(this, 16), Ui.dp(this, 18));
            gamesBox.addView(t);
            return;
        }
        for (String[] it : items) {
            try {
                gamesBox.addView(gameRow(it[1], it[0], pm.getApplicationIcon(it[1])));
            } catch (Exception ignored) {
                // sem ícone: pula
            }
        }
    }

    private View gameRow(String pkg, String name, Drawable icon) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));

        ImageView iv = new ImageView(this);
        iv.setImageDrawable(icon);
        row.addView(iv, new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46)));

        TextView n = Ui.text(this, name, 16, Ui.TEXT);
        n.setSingleLine(true);
        n.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0, WRAP, 1f);
        np.setMargins(Ui.dp(this, 14), 0, Ui.dp(this, 10), 0);
        row.addView(n, np);

        TextView go = Ui.pill(this, "Jogar", false);
        go.setTextColor(Ui.ACCENT);
        go.setPadding(Ui.dp(this, 20), Ui.dp(this, 10), Ui.dp(this, 20), Ui.dp(this, 10));
        go.setOnClickListener(x -> play(pkg));
        row.addView(go);
        return row;
    }

    // ---------------------------------------------------------------- painel

    private void refreshStats() {
        SysInfo.Mem m = SysInfo.mem(this);
        float used = m.totalKb > 0 ? 1f - (float) m.availKb / m.totalKb : 0f;
        gauge.set(used, Math.round(used * 100) + "%", "da RAM em uso");
        ramCaption.setText(SysInfo.gb(m.availKb) + " livres de " + SysInfo.gb(m.totalKb));
        swapV.setText(m.swapTotalKb > 0 ? SysInfo.gb(m.swapTotalKb - m.swapFreeKb) : "—");

        float t = SysInfo.batteryTempC(this);
        tempV.setText(t > 0 ? SysInfo.temp(t) : "—");
        tempV.setTextColor(t >= 43f ? Ui.BAD : (t >= 40f ? Ui.WARN : Ui.TEXT));

        int load = SysInfo.cpuLoadPct();
        long khz = SysInfo.cpuFreqKhz();
        if (load >= 0) {
            cpuV.setText(load + "%");
        } else if (khz > 0) {
            cpuV.setText(String.format(Locale.getDefault(), "%.1f GHz", khz / 1e6f));
        } else {
            cpuV.setText("—");
        }
        refreshAlerts();
    }

    private void refreshService() {
        boolean on = NitroAccessibilityService.instance != null;
        svcState.setText(on ? "Ativo. O Turbo fecha apps de verdade." : "Desligado. O Turbo faz só a limpeza leve.");
        svcState.setTextColor(on ? Ui.OK : Ui.WARN);
    }

    private void refreshAlerts() {
        boolean svc = NitroAccessibilityService.instance != null;
        boolean save = SysInfo.powerSave(this);
        float t = SysInfo.batteryTempC(this);
        boolean hot = SysInfo.thermal(this) >= 2 || t >= 43f;
        String key = svc + "|" + save + "|" + hot;
        if (key.equals(alertKey)) return;
        alertKey = key;
        refreshService();
        alerts.removeAllViews();
        if (!svc) {
            addAlert("Turbo total desligado",
                    "Sem o serviço de acessibilidade, o Nitro só faz a limpeza leve.",
                    "Ativar", Ui.WARN, x -> open(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }
        if (save) {
            addAlert("Economia de energia ligada",
                    "Ela segura CPU e GPU enquanto você joga.",
                    "Ajustar", Ui.WARN, x -> open(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        }
        if (hot) {
            addAlert("Aparelho quente",
                    "O Android reduz CPU e GPU sozinho pra esfriar. Dê uma pausa.",
                    null, Ui.BAD, null);
        }
    }

    private void addAlert(String title, String msg, String action, int color, View.OnClickListener l) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(Ui.ripple(this, Ui.rect(this, Ui.RAISED, 16), 16));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12));
        TextView t1 = Ui.text(this, title, 15, color);
        t1.setTypeface(Ui.medium());
        texts.addView(t1);
        texts.addView(Ui.text(this, msg, 13, Ui.MUTED), Ui.lp(this, WRAP, WRAP, 0, 3, 0, 0));
        row.addView(texts, new LinearLayout.LayoutParams(0, WRAP, 1f));

        if (action != null) {
            TextView a = Ui.text(this, action, 14, color);
            a.setTypeface(Ui.medium());
            a.setPadding(Ui.dp(this, 6), 0, Ui.dp(this, 16), 0);
            row.addView(a);
        }
        if (l != null) row.setOnClickListener(l);
        alerts.addView(row, Ui.lp(this, MATCH, WRAP, 0, 8, 0, 0));
    }

    // ---------------------------------------------------------------- construção da tela

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        sv.setFillViewport(true);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 48));
        sv.addView(col, new ViewGroup.LayoutParams(MATCH, WRAP));

        col.addView(Ui.title(this, "Nitro", 32));
        col.addView(Ui.text(this, "Mais RAM livre e menos peso em segundo plano pro seu jogo.", 14, Ui.MUTED),
                Ui.lp(this, MATCH, WRAP, 0, 4, 0, 0));

        alerts = new LinearLayout(this);
        alerts.setOrientation(LinearLayout.VERTICAL);
        col.addView(alerts, Ui.lp(this, MATCH, WRAP, 0, 10, 0, 0));

        gauge = new GaugeView(this);
        LinearLayout.LayoutParams gp = Ui.lp(this, Ui.dp(this, 280), Ui.dp(this, 280), 0, 10, 0, 0);
        gp.gravity = Gravity.CENTER_HORIZONTAL;
        col.addView(gauge, gp);

        ramCaption = Ui.text(this, "", 15, Ui.MUTED);
        ramCaption.setGravity(Gravity.CENTER_HORIZONTAL);
        col.addView(ramCaption, Ui.lp(this, MATCH, WRAP, 0, 6, 0, 0));

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        swapV = Ui.title(this, "—", 22);
        tempV = Ui.title(this, "—", 22);
        cpuV = Ui.title(this, "—", 22);
        stats.addView(stat(swapV, "Swap em uso"), new LinearLayout.LayoutParams(0, WRAP, 1f));
        stats.addView(divider());
        stats.addView(stat(tempV, "Temperatura"), new LinearLayout.LayoutParams(0, WRAP, 1f));
        stats.addView(divider());
        stats.addView(stat(cpuV, "CPU"), new LinearLayout.LayoutParams(0, WRAP, 1f));
        col.addView(stats, Ui.lp(this, MATCH, WRAP, 0, 22, 0, 0));

        turboBtn = Ui.pill(this, "Turbo", true);
        turboBtn.setTextSize(24);
        turboBtn.setTypeface(Ui.condensed());
        turboBtn.setLetterSpacing(0.04f);
        turboBtn.setOnClickListener(x -> onTurboClick());
        col.addView(turboBtn, Ui.lp(this, MATCH, Ui.dp(this, 62), 0, 26, 0, 0));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setProgressTintList(ColorStateList.valueOf(Ui.ACCENT));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(Ui.RAISED));
        progress.setVisibility(View.GONE);
        col.addView(progress, Ui.lp(this, MATCH, Ui.dp(this, 4), 0, 14, 0, 0));

        status = Ui.text(this, "Fecha o que está aberto em segundo plano. A tela pisca por alguns segundos.",
                13, Ui.MUTED);
        status.setGravity(Gravity.CENTER_HORIZONTAL);
        col.addView(status, Ui.lp(this, MATCH, WRAP, 8, 12, 8, 0));

        // Modo Jogo
        section(col, "Modo Jogo", "Fecha o resto e abre o jogo logo em seguida.");
        gamesBox = new LinearLayout(this);
        gamesBox.setOrientation(LinearLayout.VERTICAL);
        gamesBox.setBackground(Ui.rect(this, Ui.RAISED, 20));
        col.addView(gamesBox, Ui.lp(this, MATCH, WRAP, 0, 14, 0, 0));
        TextView pickGames = Ui.pill(this, "Escolher jogos", false);
        pickGames.setOnClickListener(x -> openPicker(AppsActivity.MODE_GAMES));
        col.addView(pickGames, Ui.lp(this, MATCH, WRAP, 0, 12, 0, 0));

        // O que o Turbo fecha
        section(col, "O que o Turbo fecha",
                "Tudo que está aberto e não está protegido. WhatsApp e Telegram já vêm protegidos pra você não perder mensagem.");
        TextView pickProtect = Ui.pill(this, "Escolher apps protegidos", false);
        pickProtect.setOnClickListener(x -> openPicker(AppsActivity.MODE_PROTECT));
        col.addView(pickProtect, Ui.lp(this, MATCH, WRAP, 0, 14, 0, 0));
        Switch sys = new Switch(this);
        sys.setText("Incluir apps do sistema (avançado)");
        sys.setTextColor(Ui.TEXT);
        sys.setTextSize(14);
        sys.setChecked(prefs.includeSystem());
        sys.setOnCheckedChangeListener((btn, on) -> prefs.setIncludeSystem(on));
        col.addView(sys, Ui.lp(this, MATCH, WRAP, 0, 16, 0, 0));

        // Ajustes manuais
        section(col, "Ajustes manuais que ajudam",
                "O Android não deixa app nenhum mexer nisso sem ADB, mas dá pra ligar à mão em segundos.");
        LinearLayout tweaks = new LinearLayout(this);
        tweaks.setOrientation(LinearLayout.VERTICAL);
        col.addView(tweaks, Ui.lp(this, MATCH, WRAP, 0, 8, 0, 0));
        tweaks.addView(tweak("Limite de processos em segundo plano",
                "Em Opções do desenvolvedor, escolha no máximo 4 processos e deixe as escalas de animação em 0,5x. Evite “sem processos”: quebra notificações.",
                x -> openDev()));
        tweaks.addView(tweak("Economia de energia",
                "Ligada, ela segura CPU e GPU. Desligue antes de jogar.",
                x -> open(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        tweaks.addView(tweak("Taxa de atualização da tela",
                "Em jogo que roda a 60 FPS, o modo padrão pesa menos na GPU e esquenta menos.",
                x -> open(Settings.ACTION_DISPLAY_SETTINGS)));
        tweaks.addView(tweak("Apps por cima de outros apps",
                "Bolhas e filtros de tela obrigam a GPU a compor camadas extras. Desligue o que você não usa.",
                x -> open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)));
        tweaks.addView(tweak("Nitro sem restrição de bateria",
                "Evita que o Android desligue o serviço do Turbo sozinho.",
                x -> open(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName())))));
        tweaks.addView(Ui.hairline(this));

        // Serviço
        section(col, "Serviço do Turbo",
                "O Android só deixa um app fechar outro de verdade pelo botão Forçar parada. O Nitro aperta esse botão por você, só na tela de Configurações.");
        svcState = Ui.text(this, "", 15, Ui.TEXT);
        col.addView(svcState, Ui.lp(this, MATCH, WRAP, 0, 14, 0, 0));
        TextView bOpen = Ui.pill(this, "Abrir acessibilidade", false);
        bOpen.setOnClickListener(x -> open(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        col.addView(bOpen, Ui.lp(this, MATCH, WRAP, 0, 12, 0, 0));
        TextView bHelp = Ui.pill(this, "Não consigo ativar", false);
        bHelp.setOnClickListener(x -> helpService());
        col.addView(bHelp, Ui.lp(this, MATCH, WRAP, 0, 10, 0, 0));

        TextView foot = Ui.text(this,
                "Sem root nem ADB, nenhum app consegue subir o clock da CPU ou da GPU. O ganho do Nitro vem de sobrar mais memória e menos processo disputando CPU e GPU com o seu jogo. A resolução da tela não é mexida.",
                12, Ui.MUTED);
        foot.setLineSpacing(0f, 1.15f);
        col.addView(foot, Ui.lp(this, MATCH, WRAP, 0, 36, 0, 0));

        // Tela = painel rolável + faixa do anúncio (AdMob) fixa embaixo.
        // A faixa fica escondida até o banner carregar, então sem internet nada muda.
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.addView(sv, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        adBox = new FrameLayout(this);
        adBox.setBackgroundColor(Ui.DEEP);
        adBox.setVisibility(View.GONE);
        root.addView(adBox, new LinearLayout.LayoutParams(MATCH, WRAP));
        return root;
    }

    private void section(LinearLayout col, String title, String sub) {
        col.addView(Ui.title(this, title, 22), Ui.lp(this, WRAP, WRAP, 0, 38, 0, 0));
        TextView s = Ui.text(this, sub, 13, Ui.MUTED);
        s.setLineSpacing(0f, 1.15f);
        col.addView(s, Ui.lp(this, MATCH, WRAP, 0, 6, 0, 0));
    }

    private LinearLayout stat(TextView value, String label) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        l.addView(value);
        l.addView(Ui.text(this, label, 12, Ui.MUTED), Ui.lp(this, WRAP, WRAP, 0, 4, 0, 0));
        return l;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(Ui.LINE);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Math.max(1, Ui.dp(this, 1)), Ui.dp(this, 30));
        p.gravity = Gravity.CENTER_VERTICAL;
        v.setLayoutParams(p);
        return v;
    }

    private View tweak(String title, String desc, View.OnClickListener l) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.addView(Ui.hairline(this));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 14));
        row.setBackground(Ui.rowRipple());
        row.setOnClickListener(l);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(Ui.text(this, title, 16, Ui.TEXT));
        TextView d = Ui.text(this, desc, 13, Ui.MUTED);
        d.setLineSpacing(0f, 1.15f);
        texts.addView(d, Ui.lp(this, MATCH, WRAP, 0, 4, 0, 0));
        row.addView(texts, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(Ui.text(this, "›", 24, Ui.MUTED), Ui.lp(this, WRAP, WRAP, 12, 0, 4, 0));
        wrap.addView(row);
        return wrap;
    }

    // ---------------------------------------------------------------- atalhos pro sistema

    private void openPicker(String mode) {
        Intent i = new Intent(this, AppsActivity.class);
        i.putExtra(AppsActivity.EXTRA_MODE, mode);
        startActivity(i);
    }

    private void openDev() {
        boolean on = Settings.Global.getInt(getContentResolver(), Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1;
        if (on) {
            open(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS);
            return;
        }
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Ative as Opções do desenvolvedor")
                .setMessage("Configurações > Sobre o telefone > Informações do software > toque 7 vezes em Número da versão. Depois volte aqui e toque de novo.")
                .setPositiveButton("Abrir Sobre o telefone", (d, i) -> open(Settings.ACTION_DEVICE_INFO_SETTINGS))
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void helpService() {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Como ativar o serviço")
                .setMessage("1. Toque em “Abrir acessibilidade” e procure o Nitro em Apps instalados.\n\n"
                        + "2. Se o botão estiver cinza com aviso de “configuração restrita”, abra a Info do app do Nitro, toque nos três pontinhos e escolha “Permitir configurações restritas”.\n\n"
                        + "3. Volte e ligue o serviço.\n\n"
                        + "Ele só enxerga a tela de Configurações do sistema e só serve pra tocar em “Forçar parada”.")
                .setPositiveButton("Abrir acessibilidade", (d, i) -> open(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                .setNeutralButton("Info do app", (d, i) -> open(new Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", getPackageName(), null))))
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void open(String action) {
        open(new Intent(action));
    }

    private void open(Intent i) {
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Esse atalho não existe neste aparelho.");
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
