package com.nitro.boost;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;
import java.util.Locale;

/**
 * Aperta "Forçar parada" (e confirma) na tela de Info do app, um app por vez, e volta pro Nitro.
 * Só enxerga a tela de Configurações (ver res/xml/accessibility_service_config.xml).
 * Não lê nem guarda nada: o único trabalho é achar dois botões e tocar neles.
 */
public class NitroAccessibilityService extends AccessibilityService {
    static volatile NitroAccessibilityService instance;

    // Em minúsculas. Compara o texto inteiro do botão, então o título "Forçar parada?" não confunde.
    private static final String[] STOP_LABELS = {
            "forçar parada", "forçar a parada", "forçar paragem", "forçar encerramento",
            "force stop", "force-stop", "forzar detención", "forzar parada", "forzar cierre",
            "forcer l'arrêt", "forcer l’arrêt", "beenden erzwingen"
    };
    private static final String[] OK_LABELS = {
            "ok", "forçar parada", "forçar a parada", "force stop", "sim", "yes", "confirmar", "aceitar"
    };

    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean ticking;
    private int backs;
    private long lastBack;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        ticking = false;
        h.removeCallbacksAndMessages(null);
        return super.onUnbind(intent);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // O trabalho é feito no tick(); os eventos só mantêm o serviço ativo.
    }

    @Override
    public void onInterrupt() { }

    void back() {
        performGlobalAction(GLOBAL_ACTION_BACK);
    }

    void startTicking() {
        if (ticking) return;
        ticking = true;
        h.postDelayed(tick, 200);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            TurboEngine e = TurboEngine.get(NitroAccessibilityService.this);
            if (!e.inSettings()) {
                ticking = false;
                return;
            }
            try {
                step(e);
            } catch (Throwable t) {
                toReturn(e, TurboEngine.Outcome.TIMEOUT, SystemClock.uptimeMillis());
            }
            h.postDelayed(this, 180);
        }
    };

    private void toReturn(TurboEngine e, TurboEngine.Outcome o, long now) {
        e.outcome = o;
        e.phase = TurboEngine.Phase.RETURN;
        e.phaseAt = now;
        backs = 0;
        lastBack = 0;
    }

    private void step(TurboEngine e) {
        long now = SystemClock.uptimeMillis();
        AccessibilityNodeInfo root = getRootInActiveWindow();
        CharSequence rp = root != null ? root.getPackageName() : null;
        boolean ours = rp != null && rp.toString().equals(getPackageName());

        if (e.phase != TurboEngine.Phase.RETURN && now - e.stepStart > 8500) {
            toReturn(e, TurboEngine.Outcome.TIMEOUT, now);
        }

        switch (e.phase) {
            case WAIT_BUTTON: {
                if (root == null || ours) return;
                AccessibilityNodeInfo label = find(root, STOP_LABELS, 0);
                if (label == null) return;
                AccessibilityNodeInfo btn = clickable(label);
                if (btn == null) return;
                if (!label.isEnabled() || !btn.isEnabled()) {
                    // Botão cinza: ou já está parado, ou o Android não deixa parar esse app.
                    if (Apps.isStopped(this, e.current)) {
                        toReturn(e, TurboEngine.Outcome.ALREADY, now);
                    } else if (e.disabledSince == 0) {
                        e.disabledSince = now;
                    } else if (now - e.disabledSince > 1500) {
                        toReturn(e, TurboEngine.Outcome.CANT, now);
                    }
                    return;
                }
                if (btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    e.phase = TurboEngine.Phase.WAIT_DIALOG;
                    e.phaseAt = now;
                }
                return;
            }
            case WAIT_DIALOG: {
                if (root == null || ours) return;
                AccessibilityNodeInfo ok = byId(root, "android:id/button1");
                if (ok == null && byId(root, "android:id/button2") != null) {
                    ok = find(root, OK_LABELS, 0);
                }
                if (ok == null) {
                    if (Apps.isStopped(this, e.current)) {
                        e.phase = TurboEngine.Phase.VERIFY;
                        e.phaseAt = now;
                    } else if (now - e.phaseAt > 2500) {
                        e.phase = TurboEngine.Phase.WAIT_BUTTON; // o toque não pegou; tenta de novo
                        e.phaseAt = now;
                    }
                    return;
                }
                AccessibilityNodeInfo btn = clickable(ok);
                if (btn != null && btn.isEnabled() && btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    e.phase = TurboEngine.Phase.VERIFY;
                    e.phaseAt = now;
                }
                return;
            }
            case VERIFY: {
                boolean done = Apps.isStopped(this, e.current);
                if (!done && root != null && !ours) {
                    AccessibilityNodeInfo label = find(root, STOP_LABELS, 0);
                    if (label != null && !label.isEnabled()) done = true;
                }
                if (done) {
                    toReturn(e, TurboEngine.Outcome.STOPPED, now);
                } else if (now - e.phaseAt > 2200) {
                    toReturn(e, TurboEngine.Outcome.TIMEOUT, now);
                }
                return;
            }
            case RETURN: {
                if (ours) {
                    e.endStep(e.outcome);
                    return;
                }
                if (now - lastBack >= 700) {
                    if (backs >= 6) {
                        e.endStep(e.outcome);
                        return;
                    }
                    performGlobalAction(GLOBAL_ACTION_BACK);
                    backs++;
                    lastBack = now;
                }
                return;
            }
            default:
                return;
        }
    }

    private static AccessibilityNodeInfo byId(AccessibilityNodeInfo root, String id) {
        List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByViewId(id);
        return (l == null || l.isEmpty()) ? null : l.get(0);
    }

    private static AccessibilityNodeInfo find(AccessibilityNodeInfo n, String[] labels, int depth) {
        if (n == null || depth > 40) return null;
        if (matches(n.getText(), labels) || matches(n.getContentDescription(), labels)) return n;
        int count = n.getChildCount();
        for (int i = 0; i < count; i++) {
            AccessibilityNodeInfo r = find(n.getChild(i), labels, depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    private static boolean matches(CharSequence cs, String[] labels) {
        if (cs == null) return false;
        String s = cs.toString().trim().toLowerCase(Locale.ROOT);
        for (String l : labels) {
            if (s.equals(l)) return true;
        }
        return false;
    }

    /** Sobe na árvore até achar quem aceita toque (o texto do botão quase nunca é o clicável). */
    private static AccessibilityNodeInfo clickable(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo c = n;
        for (int i = 0; i < 7 && c != null; i++) {
            if (c.isClickable()) return c;
            c = c.getParent();
        }
        return null;
    }
}
