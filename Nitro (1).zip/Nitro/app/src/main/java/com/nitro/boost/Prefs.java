package com.nitro.boost;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Guarda a lista de apps protegidos, a lista de jogos e a opção de incluir apps do sistema. */
final class Prefs {
    static final String K_PROTECT = "protect";
    static final String K_GAMES = "games";
    private static final String K_SYSTEM = "include_system";

    private static final String[] DEFAULT_PROTECT = {
            "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "org.thoughtcrime.securesms"
    };

    private final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("nitro", Context.MODE_PRIVATE);
    }

    /** Sempre devolve uma cópia que pode ser alterada. */
    Set<String> get(String key) {
        if (K_PROTECT.equals(key) && !sp.contains(K_PROTECT)) {
            Set<String> d = new HashSet<>(Arrays.asList(DEFAULT_PROTECT));
            put(K_PROTECT, d);
            return d;
        }
        return new HashSet<>(sp.getStringSet(key, new HashSet<String>()));
    }

    void put(String key, Set<String> value) {
        sp.edit().putStringSet(key, new HashSet<>(value)).apply();
    }

    boolean includeSystem() {
        return sp.getBoolean(K_SYSTEM, false);
    }

    void setIncludeSystem(boolean v) {
        sp.edit().putBoolean(K_SYSTEM, v).apply();
    }
}
