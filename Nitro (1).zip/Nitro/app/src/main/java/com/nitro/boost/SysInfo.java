package com.nitro.boost;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.PowerManager;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Locale;

/** Leituras do sistema que um app comum consegue fazer sem root nem ADB. */
final class SysInfo {
    private SysInfo() { }

    static final class Mem {
        long totalKb;
        long availKb;
        long swapTotalKb;
        long swapFreeKb;
    }

    static Mem mem(Context c) {
        Mem m = new Mem();
        try (BufferedReader br = new BufferedReader(new FileReader("/proc/meminfo"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("MemTotal:")) {
                    m.totalKb = num(line);
                } else if (line.startsWith("MemAvailable:")) {
                    m.availKb = num(line);
                } else if (line.startsWith("SwapTotal:")) {
                    m.swapTotalKb = num(line);
                } else if (line.startsWith("SwapFree:")) {
                    m.swapFreeKb = num(line);
                    break;
                }
            }
        } catch (Exception ignored) {
            // cai no ActivityManager abaixo
        }
        if (m.totalKb <= 0 || m.availKb <= 0) {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            m.totalKb = mi.totalMem / 1024;
            m.availKb = mi.availMem / 1024;
        }
        return m;
    }

    private static long num(String line) {
        StringBuilder sb = new StringBuilder();
        for (int i = line.indexOf(':') + 1; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch >= '0' && ch <= '9') {
                sb.append(ch);
            } else if (sb.length() > 0) {
                break;
            }
        }
        return sb.length() == 0 ? 0 : Long.parseLong(sb.toString());
    }

    /** Temperatura da bateria em °C, ou -1 se não der pra ler. */
    static float batteryTempC(Context c) {
        Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return -1f;
        int t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
        return t == Integer.MIN_VALUE ? -1f : t / 10f;
    }

    /** 0 = normal ... 2 = moderado (já limitando) ... 6 = desligando; -1 = indisponível. */
    static int thermal(Context c) {
        if (Build.VERSION.SDK_INT < 29) return -1;
        try {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            return pm.getCurrentThermalStatus();
        } catch (Throwable t) {
            return -1;
        }
    }

    static boolean powerSave(Context c) {
        try {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            return pm.isPowerSaveMode();
        } catch (Throwable t) {
            return false;
        }
    }

    private static long lastTotal = -1;
    private static long lastIdle = -1;

    /** Carga de CPU em %, ou -1 se o Android não deixar ler /proc/stat (ou na 1ª leitura). */
    static int cpuLoadPct() {
        try (BufferedReader br = new BufferedReader(new FileReader("/proc/stat"))) {
            String line = br.readLine();
            if (line == null || !line.startsWith("cpu")) return -1;
            String[] p = line.trim().split("\\s+");
            if (p.length < 9) return -1;
            long idle = Long.parseLong(p[4]) + Long.parseLong(p[5]);
            long total = 0;
            for (int i = 1; i <= 8; i++) total += Long.parseLong(p[i]);
            int pct = -1;
            if (lastTotal >= 0 && total > lastTotal) {
                float busy = (total - lastTotal) - (idle - lastIdle);
                pct = Math.max(0, Math.min(100, Math.round(100f * busy / (total - lastTotal))));
            }
            lastTotal = total;
            lastIdle = idle;
            return pct;
        } catch (Exception e) {
            return -1;
        }
    }

    /** Maior clock atual entre os núcleos, em kHz, ou -1 se o Android esconder isso. */
    static long cpuFreqKhz() {
        long best = -1;
        int n = Runtime.getRuntime().availableProcessors();
        for (int i = 0; i < n; i++) {
            try (BufferedReader br = new BufferedReader(
                    new FileReader("/sys/devices/system/cpu/cpu" + i + "/cpufreq/scaling_cur_freq"))) {
                String l = br.readLine();
                if (l != null) best = Math.max(best, Long.parseLong(l.trim()));
            } catch (Exception ignored) {
                // núcleo desligado ou sem permissão
            }
        }
        return best;
    }

    static String gb(long kb) {
        return String.format(Locale.getDefault(), "%.1f GB", kb / 1048576f);
    }

    static String temp(float c) {
        return String.format(Locale.getDefault(), "%.1f °C", c);
    }
}
