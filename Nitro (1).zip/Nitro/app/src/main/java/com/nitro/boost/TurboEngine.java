package com.nitro.boost;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import java.util.ArrayList;
import java.util.List;

/**
 * Orquestra o Turbo. Primeiro a limpeza leve (killBackgroundProcesses) em todos os alvos;
 * depois, se o serviço de acessibilidade estiver ligado, um "Forçar parada" de verdade por app.
 * A tela principal abre a Info do app (ela precisa estar na frente) e o serviço aperta os botões.
 */
final class TurboEngine {
    enum State { IDLE, NEEDS_LAUNCH, IN_SETTINGS, MEASURING }

    enum Phase { WAIT_BUTTON, WAIT_DIALOG, VERIFY, RETURN }

    enum Outcome { STOPPED, ALREADY, CANT, TIMEOUT }

    interface Listener {
        /** Terminou um app; pode abrir o próximo. */
        void onNext();

        /** Acabou tudo. */
        void onDone(Result r);
    }

    static final class Result {
        int total;
        int stopped;
        int skipped;
        int failed;
        long availBeforeKb;
        long availAfterKb;
        boolean deep;
        String launch;
    }

    private static TurboEngine inst;

    static synchronized TurboEngine get(Context c) {
        if (inst == null) inst = new TurboEngine(c.getApplicationContext());
        return inst;
    }

    final Context app;
    private final Handler h = new Handler(Looper.getMainLooper());
    private Listener listener;

    State state = State.IDLE;
    Phase phase = Phase.WAIT_BUTTON;
    Outcome outcome = Outcome.TIMEOUT;
    String current;
    long stepStart;
    long phaseAt;
    long disabledSince;
    final List<String> queue = new ArrayList<>();
    int idx;
    Result result = new Result();

    private TurboEngine(Context app) {
        this.app = app;
    }

    void setListener(Listener l) {
        listener = l;
    }

    boolean busy() {
        return state != State.IDLE;
    }

    boolean inSettings() {
        return state == State.IN_SETTINGS;
    }

    /** Começa o Turbo. launchAfter = pacote do jogo que abre no fim (e que não é fechado). */
    boolean start(String launchAfter) {
        if (busy()) return false;
        result = new Result();
        result.launch = launchAfter;
        result.availBeforeKb = SysInfo.mem(app).availKb;

        List<String> targets = Apps.targets(app, launchAfter);
        result.total = targets.size();

        ActivityManager am = (ActivityManager) app.getSystemService(Context.ACTIVITY_SERVICE);
        for (String p : targets) {
            try {
                am.killBackgroundProcesses(p);
            } catch (Exception ignored) {
                // alguns apps não deixam; segue
            }
        }

        queue.clear();
        idx = 0;
        if (NitroAccessibilityService.instance != null && !targets.isEmpty()) {
            queue.addAll(targets);
            result.deep = true;
            state = State.NEEDS_LAUNCH;
        } else {
            state = State.MEASURING;
            finishSoon();
        }
        return true;
    }

    /** Próximo pacote pra abrir na tela de Info; null se acabou a fila. */
    String takeNext() {
        if (state != State.NEEDS_LAUNCH || idx >= queue.size()) return null;
        current = queue.get(idx++);
        state = State.IN_SETTINGS;
        phase = Phase.WAIT_BUTTON;
        outcome = Outcome.TIMEOUT;
        disabledSince = 0;
        stepStart = SystemClock.uptimeMillis();
        phaseAt = stepStart;
        h.removeCallbacks(watchdog);
        h.postDelayed(watchdog, 15000);
        NitroAccessibilityService s = NitroAccessibilityService.instance;
        if (s != null) s.startTicking();
        return current;
    }

    /** O serviço (ou o watchdog) chama isso quando terminou um app e já voltou pro Nitro. */
    void endStep(Outcome o) {
        if (state != State.IN_SETTINGS) return;
        h.removeCallbacks(watchdog);
        switch (o) {
            case STOPPED:
                result.stopped++;
                break;
            case ALREADY:
            case CANT:
                result.skipped++;
                break;
            default:
                result.failed++;
                break;
        }
        state = State.NEEDS_LAUNCH;
        if (listener != null) listener.onNext();
    }

    /** A fila acabou: mede a RAM e avisa. */
    void finishRun() {
        if (state != State.NEEDS_LAUNCH) return;
        state = State.MEASURING;
        finishSoon();
    }

    /** Descarta o que falta; o app atual termina normalmente. */
    void cancel() {
        if (state == State.NEEDS_LAUNCH || state == State.IN_SETTINGS) {
            while (queue.size() > idx) queue.remove(queue.size() - 1);
        }
    }

    private void finishSoon() {
        long delay = result.launch != null ? 200 : 1300;
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                result.availAfterKb = SysInfo.mem(app).availKb;
                state = State.IDLE;
                if (listener != null) listener.onDone(result);
            }
        }, delay);
    }

    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            if (state != State.IN_SETTINGS) return;
            NitroAccessibilityService s = NitroAccessibilityService.instance;
            if (s != null) s.back();
            endStep(Outcome.TIMEOUT);
        }
    };
}
