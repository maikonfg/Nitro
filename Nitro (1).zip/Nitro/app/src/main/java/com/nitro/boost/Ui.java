package com.nitro.boost;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Visual de painel de instrumentos: azul-petróleo de fundo, coral pra ação, menta pra "ok". */
final class Ui {
    static final int BG = 0xFF0E2A36;
    static final int DEEP = 0xFF0A1F29;
    static final int RAISED = 0xFF16394A;
    static final int LINE = 0xFF24505F;
    static final int TEXT = 0xFFEAF3F6;
    static final int MUTED = 0xFF8FB0BE;
    static final int ACCENT = 0xFFFF6F59;
    static final int OK = 0xFF4FE3C1;
    static final int WARN = 0xFFFFC857;
    static final int BAD = 0xFFFF5A5F;

    private Ui() { }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable rect(Context c, int fill, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static GradientDrawable outline(Context c, int fill, int stroke, float radiusDp) {
        GradientDrawable g = rect(c, fill, radiusDp);
        g.setStroke(Math.max(1, dp(c, 1)), stroke);
        return g;
    }

    static Drawable ripple(Context c, Drawable content, float radiusDp) {
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), content, rect(c, Color.WHITE, radiusDp));
    }

    static Drawable rowRipple() {
        return new RippleDrawable(ColorStateList.valueOf(0x22FFFFFF), null, new ColorDrawable(Color.WHITE));
    }

    static Typeface condensed() {
        return Typeface.create("sans-serif-condensed", Typeface.BOLD);
    }

    static Typeface medium() {
        return Typeface.create("sans-serif-medium", Typeface.NORMAL);
    }

    static TextView text(Context c, CharSequence s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        return t;
    }

    static TextView title(Context c, CharSequence s, float sp) {
        TextView t = text(c, s, sp, TEXT);
        t.setTypeface(condensed());
        return t;
    }

    static TextView pill(Context c, CharSequence label, boolean primary) {
        TextView b = text(c, label, 16, primary ? DEEP : TEXT);
        b.setTypeface(medium());
        b.setGravity(Gravity.CENTER);
        int px = dp(c, 20);
        int py = dp(c, 14);
        b.setPadding(px, py, px, py);
        Drawable bg = primary ? rect(c, ACCENT, 30) : outline(c, RAISED, LINE, 30);
        b.setBackground(ripple(c, bg, 30));
        b.setClickable(true);
        return b;
    }

    /** w e h em pixels (ou MATCH/WRAP); margens em dp. */
    static LinearLayout.LayoutParams lp(Context c, int w, int h, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    static View hairline(Context c) {
        View v = new View(c);
        v.setBackgroundColor(LINE);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, 0.5f))));
        return v;
    }
}
